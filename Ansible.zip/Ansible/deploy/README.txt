This playbook creates 4 nodes, one as master and 3 as workers. It does the following initial configurations on the nodes:

1. Attaches the security groups
2. Format and mount the volumes
3. Adds proxy configurations

To deploy:


Run the run.sh script. (Before running the playbook give read access to the key files (both ppk and pem) as > chmod 400 Node1-key.pem