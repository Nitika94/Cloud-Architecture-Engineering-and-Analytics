. ./openrc.sh; ansible-playbook --ask-become-pass --key-file=Node1-key.pem  nectar.yaml
