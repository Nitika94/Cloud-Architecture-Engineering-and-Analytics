. ./openrc.sh; ansible-playbook -i hosts -u ubuntu --key-file=Node1-key.pem harvester.yaml

