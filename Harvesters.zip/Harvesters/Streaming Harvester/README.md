# Prerequisites
The python package tweepy needs to be installed prior to executing the tweet harvesters.

# Steps for executing the tweet harvester

To execute tweet harvesting with the Streaming API:
	python TwitterHarvesterWithStreaming.py --config config.json --ip server_ip --port server_port
	
	Example: python TwitterHarvesterWithStreaming.py --config config.json --ip 172.26.37.252 --port 5984

Since twitter harvester should keep on executing for a lengthy duration, in actual program execution it is best to run it in the background.

In order to do this follow the steps below:

	1. Include this line at the top of the script:	#!/usr/bin/env python
	2. Make the script executable: chmod +x TwitterHarvesterWithStreaming.py
	3. Run the script in background in detached mode with command: nohup /absolute-path-to-file/TwitterHarvesterWithStreaming.py --config config.json --ip 172.26.37.252 --port 5984 &

